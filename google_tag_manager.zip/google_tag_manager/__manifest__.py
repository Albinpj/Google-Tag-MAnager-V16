{
    'name': 'Google Tag Manager',
    'version': '16.0.1.0.0',
    'summary': """Deploy And Update Measurement Tags On Your Website""",
    'description': """Deploy And Update Measurement Tags On Your Website""",
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'website': "https://www.cybrosys.com",
    'maintainer': 'Cybrosys Techno Solutions',
    'depends': ['base', 'contacts', 'website'],
    'data': [
        'views/website.xml',
        'views/google_tag_manager.xml'
    ],

    'license': 'LGPL-3',
    'price': 29,
    'currency': 'EUR',
    'installable': True,
    'auto_install': False,
    'application': False,
}
